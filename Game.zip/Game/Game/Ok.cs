﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Ok:Cephane
    {
        int zehirdarbe;

        public int Zehirdarbe
        {
            get
            {
                return zehirdarbe;
            }

            set
            {
                zehirdarbe = value;
            }
        }
    }
}
